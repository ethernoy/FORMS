# FORMS-BC v1.0

深圳中学高中部东校区校园于2010年的Minecraft模型快照，请使用Minecraft 1.9.4版客户端打开。本存档于2020年9月21日打包发布。

## Repository

[GitHub](https://github.com/ethernoy/forms)

## 开源协议

[MIT License](LICENSE)

Copyright (c) [2020] [Zicong Su, Yizhou Pan and other Contributors]
